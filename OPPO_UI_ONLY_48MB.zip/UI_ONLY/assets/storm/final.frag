#version 300 es

precision lowp float;

uniform sampler2D u_tex0;
uniform float u_strength;
uniform float u_color;

in highp vec2 v_texCoord0;

out vec4 fragColor;

void main() {
    float alpha = texture(u_tex0, v_texCoord0).r;
    fragColor = vec4(vec3(u_color), alpha * u_strength);
}