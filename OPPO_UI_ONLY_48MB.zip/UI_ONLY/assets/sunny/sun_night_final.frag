#version 300 es

precision lowp float;

uniform sampler2D u_tex0;
uniform sampler2D u_tex1;
uniform float u_alpha;
in vec2 v_texCoord0;

out vec4 fragColor;

void main() {
    vec4 color = texture(u_tex0, v_texCoord0);
    //折叠屏中星轨底部会被FBO裁剪掉一部分，底部添加羽化效果
    float eclosionRate = smoothstep(0.05, 0.15, v_texCoord0.y);
    fragColor = vec4(vec3(1.0), color.r * color.g);
    fragColor *= (eclosionRate * u_alpha);
}