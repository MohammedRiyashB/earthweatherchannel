#version 300 es

precision lowp float;

in float v_alpha;

out vec4 fragColor;
float cof = 5.0;

void main() {
    float d = distance(gl_PointCoord.xy, vec2(0.5, 0.5));
    float alphaGlow = 1.0 / (cof * d * d + 1.0);
    alphaGlow = smoothstep(0.5, 1.0, alphaGlow);
    float alphaBody = 1.0 - smoothstep(0.125, 0.175, d);
    fragColor = vec4((alphaBody + alphaGlow) * v_alpha, 1.0, 0.0, 0.0);
}