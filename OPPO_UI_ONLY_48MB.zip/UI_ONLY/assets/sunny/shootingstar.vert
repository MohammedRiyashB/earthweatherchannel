#version 300 es

uniform float u_time;
uniform vec3 u_dir;
uniform float u_speed;
uniform float u_start;

in vec3 a_position;
in float a_alpha;

out float v_alpha;
out float v_x;

void main()	{
    v_alpha = a_alpha;

    vec3 position = a_position + u_dir * u_speed * (u_time - u_start);
    v_x = position.x;
    gl_Position = vec4(position, 1.0);
}