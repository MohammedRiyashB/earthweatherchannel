#version 300 es

precision highp float;

uniform sampler2D u_tex0;
uniform sampler2D u_tex1;
uniform float u_alphaDecrease;

in vec2 v_texCoord0;

out vec4 fragColor;

void main() {
    vec4 color0 = texture(u_tex0, v_texCoord0);
    vec4 color1 = texture(u_tex1, v_texCoord0);

    color0.g -= u_alphaDecrease;
    if (color0.g < 0.45){
        color0.g = 0.0;
    }

    vec4 color;

    if(color0.r * color0.g < color1.r){
        color = color1;
    }else{
        color = color0;
    }

    //    alpha0 -= 0.003;
    //    if(alpha0<0.5){
    //        alpha0 = 0.0;
    //    }

//    fragColor = vec4(vec3(max(alpha0, alpha1)), 1.0);
    fragColor = color;
}