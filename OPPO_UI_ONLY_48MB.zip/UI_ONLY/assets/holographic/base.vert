#version 300 es
layout(location = 0) in vec4 a_position;
layout(location = 1) in vec2 a_texCoord0;
out vec2 v_texCoord0;
void main()
{
   gl_Position = a_position;
   v_texCoord0 = a_texCoord0;
}