#version 300 es
precision lowp float;

uniform sampler2D u_tex0;
uniform float u_alpha;
uniform float u_needMirror;

in vec2 v_texCoord0;
out vec4 fragColor;

void main() {
    vec2 coord = v_texCoord0;
    coord.x = abs(coord.x - u_needMirror);
    vec4 color = texture(u_tex0, coord);
    fragColor = vec4(vec3(1.0), color.r * color.g * u_alpha);
}