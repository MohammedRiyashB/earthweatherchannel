#version 300 es

precision mediump float;

uniform sampler2D u_tex0;
uniform float u_alpha;

in vec2 v_texCoord0;

out vec4 fragColor;

float rand(vec2 c){
    return fract(sin(dot(c.xy, vec2(12.9898, 78.233))) * 43758.5453);
}

void main()	{
    float dither = mix(-0.004, 0.004, rand(v_texCoord0));
    fragColor = vec4(texture(u_tex0, v_texCoord0) + dither);
    fragColor.a *= u_alpha;
}