#version 300 es

in vec4 a_position;
in vec2 a_texCoord0;

out vec2 v_texCoord0;

void main()	{
    v_texCoord0 = a_texCoord0 * vec2(1.0, 0.6);
    float y = a_position.y * 0.6 + 0.4;
    gl_Position = vec4(a_position.x, y, a_position.z, 1.0);
}