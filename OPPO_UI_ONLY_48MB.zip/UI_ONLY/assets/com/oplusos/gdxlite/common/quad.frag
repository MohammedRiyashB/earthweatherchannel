#version 300 es

uniform sampler2D u_tex0;

in vec2 v_texCoord0;

layout(location = 0) out vec4 fragColor;

void main()	{
    fragColor = vec4(texture(u_tex0, v_texCoord0).rgb, 1.);
}