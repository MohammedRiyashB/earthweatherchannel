#extension GL_OES_EGL_image_external : require

precision highp float;

uniform samplerExternalOES u_tex0;
uniform float u_alpha;

varying vec2 v_texCoord0;

void main() {
    vec4 color = texture2D(u_tex0, v_texCoord0);
    gl_FragColor = vec4(color.rgb, color.a * u_alpha);
}