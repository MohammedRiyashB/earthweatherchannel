uniform mat4 u_stMatrix;
uniform mat4 u_projTrans;

attribute vec4 a_position;
attribute vec4 a_texCoord0;

varying vec2 v_texCoord0;

void main() {
    gl_Position = u_projTrans * a_position;
    v_texCoord0 = (u_stMatrix * a_texCoord0).xy;
}