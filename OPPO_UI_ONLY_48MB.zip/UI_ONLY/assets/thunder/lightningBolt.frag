#ifdef GL_ES
precision highp float;
#endif

varying vec2 v_texCoord;
varying vec4 v_color;
uniform sampler2D CC_Texture0;
uniform float u_opacity;
uniform float u_pow;
uniform vec3 bg_color;

void main() {
    vec4 texColor=texture2D(CC_Texture0, v_texCoord);

    float alpha = exp(texColor.a);
    float fact = pow(alpha, u_pow);  //1.8
    //float fact = pow(alpha, 30.0);
    //fact = min(fact, 1.9);
    gl_FragColor=texColor*v_color*u_opacity * fact;
}

