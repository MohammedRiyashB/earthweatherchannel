#version 300 es

precision highp float;

uniform sampler2D u_tex0;

in vec2 v_texCoord0;
out vec4 fragColor;

void main() {
    fragColor = texture(u_tex0, v_texCoord0);
}