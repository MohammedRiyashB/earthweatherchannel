#version 300 es

precision mediump float;

uniform sampler2D u_tex0;
uniform float u_alpha;
uniform float u_needMirror;

in vec2 v_texCoord0;

out vec4 fragColor;

void main() {
    vec2 coord = v_texCoord0;
    coord.x = abs(coord.x - u_needMirror);
    fragColor = texture(u_tex0, coord);
}