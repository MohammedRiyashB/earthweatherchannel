#version 300 es

precision lowp float;

uniform sampler2D u_tex0;
uniform float u_alpha;

in highp vec2 v_texCoord0;

out vec4 fragColor;

void main() {
    float alpha = texture(u_tex0, v_texCoord0).r;
    fragColor = vec4(vec3(0.6), alpha * u_alpha);
}