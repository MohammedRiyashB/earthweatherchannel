#version 300 es

in vec4 a_position;
in vec2 a_texCoord0;
uniform int u_period;

out vec2 v_texCoord0;

void main()	{
    if(u_period == 1){
        v_texCoord0 = a_texCoord0 * vec2(1.0, 0.8);
        float y = a_position.y * 0.8 + 0.2;
        gl_Position = vec4(a_position.x, y, a_position.z, 1.0);
    } else {
        v_texCoord0 = a_texCoord0 * vec2(1.0, 0.6);
        float y = a_position.y * 0.6 + 0.4;
        gl_Position = vec4(a_position.x, y, a_position.z, 1.0);
    }
}