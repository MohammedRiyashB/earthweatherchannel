#version 300 es

precision mediump float;

in highp vec2 v_texCoord0;
uniform sampler2D u_tex0;
out vec4 fragColor;


void main() {
    fragColor = texture(u_tex0, v_texCoord0);
}