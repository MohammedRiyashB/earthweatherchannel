#version 300 es

precision mediump float;

uniform sampler2D u_tex0;
uniform float u_alpha;
in highp vec2 v_texCoord0;
out vec4 fragColor;
void main() {
    vec4 color = texture(u_tex0, v_texCoord0);
    fragColor = vec4(color.rgb, u_alpha);
}