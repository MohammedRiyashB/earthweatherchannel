#version 310 es
layout (location = 0) in vec4 position;

uniform mat4 u_projViewTrans;
uniform vec4 color;

out vec4 v_fragmentColor;
out vec2 v_texCoord;

void main()
{
    gl_Position =  u_projViewTrans * vec4(position.xy, 0.0, 1.0);

	v_fragmentColor = color;
	v_texCoord = position.zw;
}