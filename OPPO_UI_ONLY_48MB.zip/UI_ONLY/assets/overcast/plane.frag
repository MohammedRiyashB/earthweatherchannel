#version 310 es
#extension GL_EXT_gpu_shader5 : enable
precision mediump float;

uniform sampler2D planeMap;
out vec4 outColor;
in vec2 v_texCoord0;
void main()
{
    outColor = texture(planeMap, v_texCoord0);
}
